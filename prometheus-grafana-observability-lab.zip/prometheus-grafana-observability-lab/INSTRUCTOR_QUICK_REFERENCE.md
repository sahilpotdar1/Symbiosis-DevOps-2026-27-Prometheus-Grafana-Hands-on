# Instructor Quick Reference

## URLs
Prometheus: http://localhost:9090
cAdvisor: http://localhost:8080
App: http://localhost:8000
Metrics: http://localhost:8000/metrics
Grafana: http://localhost:3000

## Start
docker compose up -d --build
docker compose ps

## PromQL
up
up{job="pipeline-app"}
app_requests_total
rate(app_requests_total[1m])
pipeline_runs_total
sum by (status) (rate(pipeline_runs_total[5m]))
100 * sum(rate(pipeline_runs_total{status="success"}[5m])) / sum(rate(pipeline_runs_total[5m]))
rate(pipeline_duration_seconds_sum[5m]) / rate(pipeline_duration_seconds_count[5m])
pipeline_active_builds
container_memory_working_set_bytes

## Grafana datasource
http://prometheus:9090

## Failure demo
docker compose stop pipeline-app
# wait 10–15 sec; target becomes DOWN
docker compose start pipeline-app
