# PROMETHEUS + GRAFANA
## OBSERVABILITY HANDS-ON COMMAND EXECUTION GUIDE
**macOS + Windows | 2.5-hour classroom practical**

> **Start here**
>
> This practical continues from the Docker practical. Docker Desktop should already be installed and running. We will build a small near-real DevOps monitoring setup: a CI/CD pipeline + application metrics → Prometheus → Grafana.

---

## 1. What we are building

```text
                  ┌─────────────────────┐
                  │   Pipeline / App    │
                  │     :8000/metrics   │
                  └──────────┬──────────┘
                             │ scrape
                             ▼
┌──────────────┐       ┌──────────────┐
│   cAdvisor   │──────►│  Prometheus  │
│ container    │scrape │    :9090     │
│ metrics      │       └──────┬───────┘
└──────────────┘              │ PromQL
                              ▼
                       ┌──────────────┐
                       │   Grafana    │
                       │    :3000     │
                       └──────┬───────┘
                              ▼
                     DevOps Dashboard
```

**Real-world idea:** The application team exposes application/pipeline metrics; Prometheus collects them; Grafana turns them into an operations dashboard.

| Component | What students see |
|---|---|
| Prometheus | Scraping, targets, time-series metrics, PromQL, GUI |
| cAdvisor | Exporter-style container metrics |
| Grafana | Data source, Explore, panels, dashboard |
| Pipeline App | Build/deployment + application metrics |

---

## 2. Fundamentals covered

| Syllabus item | Practical coverage |
|---|---|
| Introduction + features | Prometheus/Grafana workflow |
| Architecture | scrape/evaluation, TSDB, PromQL, exporters, Grafana data source |
| Installation & setup | Docker Compose |
| Advantages / limitations | short instructor discussion |
| Monitoring using Prometheus | Targets + queries |
| Dashboard visualization | Grafana Explore + panels |
| Pipeline monitoring dashboard | CI/CD dashboard |
| GUI / plugins | Prometheus UI + Grafana data-source/plugin concept |

---

## 3. 2.5-hour practical flow

| Time | Activity | Main output |
|---|---|---|
| 0–10 min | Verify Docker + files | Lab ready |
| 10–25 | Start stack | 4 containers |
| 25–45 | Prometheus GUI | Targets + metrics |
| 45–65 | PromQL | Application + pipeline metrics |
| 65–85 | Grafana GUI | Prometheus data source + Explore |
| 85–120 | Dashboard | 6 panels |
| 120–135 | Real failure test | DOWN → UP |
| 135–145 | Final challenge | 2 student panels |
| 145–150 | Cleanup | Lab stopped |

**Classroom rule:** After Docker is installed, commands are almost identical on macOS and Windows. Folder navigation is the main difference.

---

# 4. Installation / setup

## 4.1 macOS

Docker Desktop should already be installed.

```bash
docker --version
docker compose version
docker run --rm hello-world
```

If Docker is not running, start Docker Desktop and wait until it is ready.

## 4.2 Windows PowerShell

Docker Desktop should already be installed.

```powershell
docker --version
docker compose version
docker run --rm hello-world
```

Use Linux containers in Docker Desktop.

---

# 5. Prepare the lab

### macOS

```bash
cd ~/Downloads/prometheus-grafana-observability-lab
pwd
ls
```

### Windows PowerShell

```powershell
cd "$HOME\Downloads\prometheus-grafana-observability-lab"
Get-Location
Get-ChildItem
```

### Folder structure

```text
prometheus-grafana-observability-lab/
├── docker-compose.yml
├── README.md
├── prometheus/
│   └── prometheus.yml
└── pipeline-app/
    ├── app.py
    ├── Dockerfile
    └── requirements.txt
```

---

# 6. Start the monitoring stack

```bash
docker compose up -d --build
docker compose ps
```

Expected:

```text
obs-prometheus
obs-cadvisor
obs-pipeline-app
obs-grafana
```

All should be running.

If something is not running:

```bash
docker compose logs <service-name>
```

Example:

```bash
docker compose logs prometheus
```

---

# 7. Understand the architecture before opening the GUIs

### Prometheus

Prometheus does four important things in this lab:

```text
Discover/configure target
        ↓
Scrape /metrics
        ↓
Store time-series data
        ↓
Query with PromQL
```

The `scrape_configs` in:

```text
prometheus/prometheus.yml
```

define the monitored targets.

### Open the configuration

```yaml
scrape_configs:
  - job_name: prometheus
    static_configs:
      - targets: ["prometheus:9090"]

  - job_name: cadvisor
    static_configs:
      - targets: ["cadvisor:8080"]

  - job_name: pipeline-app
    metrics_path: /metrics
    static_configs:
      - targets: ["pipeline-app:8000"]
```

**Important Docker concept:** inside the Compose network, `prometheus`, `cadvisor` and `pipeline-app` are service names.

---

# 8. Application metrics

Open:

```text
http://localhost:8000/health
```

Expected:

```text
OK
```

Open:

```text
http://localhost:8000/metrics
```

Find:

```text
app_requests_total
app_request_duration_seconds
app_service_health

pipeline_runs_total
pipeline_duration_seconds
pipeline_last_run_success
pipeline_active_builds
deployment_status
```

This is the basic Prometheus instrumentation model:

```text
Application → /metrics → Prometheus
```

---

# 9. Prometheus GUI - Targets

Open:

```text
http://localhost:9090
```

### GUI procedure

1. Open **Status → Targets**.
2. Find:
   - `prometheus`
   - `cadvisor`
   - `pipeline-app`
3. Confirm their state is **UP**.
4. Open the `pipeline-app` target details.
5. Note the scrape endpoint:
   ```text
   http://pipeline-app:8000/metrics
   ```

### Checkpoint

All three targets should be **UP**.

---

# 10. Prometheus GUI - first queries

Go to the Prometheus **Query / Expression** page.

Run:

```promql
up
```

Meaning:

```text
1 = target reachable
0 = target unavailable
```

Now run:

```promql
up{job="pipeline-app"}
```

Then:

```promql
app_requests_total
```

Then:

```promql
pipeline_runs_total
```

Switch between the **Table** and **Graph** views where available.

### Instructor point

This is the difference between:

```text
Metric
```

and:

```text
Time series = metric + labels + timestamped samples
```

---

# 11. PromQL fundamentals

Run these in the Prometheus GUI.

### A. Select a metric

```promql
app_requests_total
```

### B. Filter using a label

```promql
pipeline_runs_total{status="success"}
```

### C. Calculate request rate

```promql
rate(app_requests_total[1m])
```

### D. Pipeline run rate

```promql
rate(pipeline_runs_total[5m])
```

### E. Group pipeline runs by status

```promql
sum by (status) (
  rate(pipeline_runs_total[5m])
)
```

### F. Pipeline success percentage

```promql
100 *
sum(rate(pipeline_runs_total{status="success"}[5m]))
/
sum(rate(pipeline_runs_total[5m]))
```

### G. Average pipeline duration

```promql
rate(pipeline_duration_seconds_sum[5m])
/
rate(pipeline_duration_seconds_count[5m])
```

**Checkpoint:** students should understand `metric`, `{label="value"}`, `rate()`, `sum by()`.

---

# 12. cAdvisor - container monitoring

Open:

```text
http://localhost:8080
```

Then:

```text
http://localhost:8080/metrics
```

cAdvisor exposes container resource metrics for Prometheus.

Back in Prometheus, run:

```promql
container_cpu_usage_seconds_total
```

Then:

```promql
container_memory_working_set_bytes
```

If the returned labels differ between Docker Desktop versions, inspect the available labels rather than changing the Prometheus configuration.

### Instructor point

```text
Application metrics → application instrumentation
Container metrics   → cAdvisor
```

Both can be scraped by Prometheus.

---

# 13. Grafana - first login

Open:

```text
http://localhost:3000
```

Login:

```text
Username: admin
Password: admin
```

If Grafana asks for a new password, set one for the lab.

---

# 14. Grafana - add Prometheus data source

### GUI procedure

1. Open **Connections**.
2. Select **Add new connection** / **Data sources**.
3. Search for **Prometheus**.
4. Select **Prometheus**.
5. Set the URL to:

```text
http://prometheus:9090
```

6. Click **Save & test**.

### Important

Do NOT use:

```text
http://localhost:9090
```

for this Docker-to-Docker connection.

`localhost` inside Grafana means the Grafana container itself.

### Fundamentals

Grafana uses a **data source** to query stored monitoring data.

The Prometheus data source is built into Grafana; additional data sources can be supplied through Grafana's plugin/data-source ecosystem.

---

# 15. Grafana - Explore

Open:

```text
Explore
```

Select:

```text
Prometheus
```

Run:

```promql
up
```

Then:

```promql
rate(app_requests_total[1m])
```

Then:

```promql
sum by (status) (
  rate(pipeline_runs_total[5m])
)
```

### Why Explore?

```text
Explore = investigate/query
Dashboard = continuously visualize
```

This is a useful real-world distinction.

---

# 16. Create the DevOps monitoring dashboard

Create:

```text
Dashboards → New → New dashboard
```

Dashboard name:

```text
DevOps Pipeline & Service Monitoring
```

Create the following panels.

---

## Panel 1 - Service Availability

**Query**

```promql
up{job="pipeline-app"}
```

**Visualization:** Stat

**Title:**

```text
Pipeline Service Availability
```

---

## Panel 2 - Pipeline Success Rate

**Query**

```promql
100 *
sum(rate(pipeline_runs_total{status="success"}[5m]))
/
sum(rate(pipeline_runs_total[5m]))
```

**Visualization:** Stat

**Unit:** Percent (0–100)

**Title:**

```text
Pipeline Success Rate
```

---

## Panel 3 - Pipeline Run Rate

**Query**

```promql
sum by (status) (
  rate(pipeline_runs_total[5m])
)
```

**Visualization:** Time series

**Title:**

```text
Pipeline Run Rate
```

This should show separate success/failed series.

---

## Panel 4 - Average Build Duration

**Query**

```promql
rate(pipeline_duration_seconds_sum[5m])
/
rate(pipeline_duration_seconds_count[5m])
```

**Visualization:** Time series

**Unit:** seconds

**Title:**

```text
Average Pipeline Duration
```

---

## Panel 5 - Active Builds

**Query**

```promql
pipeline_active_builds
```

**Visualization:** Stat

**Title:**

```text
Active Builds
```

---

## Panel 6 - Container Memory

**Query**

```promql
sum by (name) (
  container_memory_working_set_bytes{name!=""}
)
```

**Visualization:** Time series

**Title:**

```text
Container Memory Usage
```

Use an appropriate bytes/memory unit.

---

# 17. Final dashboard layout

Arrange the panels approximately like:

```text
┌────────────────┬────────────────┬────────────────┐
│ Service        │ Pipeline       │ Active         │
│ Availability   │ Success Rate   │ Builds         │
├────────────────┴────────────────┴────────────────┤
│              Pipeline Run Rate                   │
├───────────────────────────────────────────────────┤
│           Average Pipeline Duration               │
├───────────────────────────────────────────────────┤
│             Container Memory Usage                │
└───────────────────────────────────────────────────┘
```

Set dashboard refresh to approximately:

```text
5s / 10s
```

Save the dashboard.

---

# 18. Make the dashboard behave like a real system

Open:

```text
http://localhost:8000/simulate
```

Refresh it a few times.

Then return to Grafana.

Observe:

- request activity
- pipeline runs
- success/failure
- duration
- active builds
- container resource usage

### Instructor explanation

A production dashboard should answer:

```text
Is the service UP?
        ↓
Are deployments succeeding?
        ↓
How often are builds running?
        ↓
Are builds becoming slower?
        ↓
Is infrastructure/container usage increasing?
```

---

# 19. Failure simulation

Now demonstrate an actual incident.

Run:

```bash
docker compose stop pipeline-app
```

Wait 10–15 seconds.

### Prometheus GUI

Go to:

```text
Status → Targets
```

`pipeline-app` should become:

```text
DOWN
```

Run:

```promql
up{job="pipeline-app"}
```

Expected:

```text
0
```

### Grafana

Return to the dashboard.

The **Service Availability** panel should reflect the failure.

This demonstrates the complete monitoring chain:

```text
Service failure
      ↓
/metrics unavailable
      ↓
Prometheus scrape fails
      ↓
up = 0
      ↓
Grafana dashboard changes
```

---

# 20. Recover the service

```bash
docker compose start pipeline-app
```

Wait a few seconds.

Prometheus:

```text
pipeline-app → UP
```

Query:

```promql
up{job="pipeline-app"}
```

Expected:

```text
1
```

Grafana should recover automatically on the next refresh.

---

# 21. Final student challenge

Students create **two additional panels**.

### Challenge A — Failed pipeline runs

```promql
sum(pipeline_runs_total{status="failed"})
```

Choose a suitable visualization.

Title:

```text
Failed Pipeline Runs
```

### Challenge B — Production deployment status

```promql
deployment_status{environment="production"}
```

Choose a suitable visualization.

Title:

```text
Production Deployment Status
```

---

# 22. Quick fixes

| Error / symptom | First thing to check |
|---|---|
| `docker` not found | Start Docker Desktop; reopen terminal |
| Docker daemon error | Docker Desktop must be Ready |
| `docker compose` fails | Run `docker compose version` |
| Port 3000/8000/8080/9090 busy | Stop the conflicting app or change host port |
| Prometheus target DOWN | `docker compose ps` + `docker compose logs <service>` |
| Grafana cannot connect | Use `http://prometheus:9090` |
| No PromQL data | Check target is UP and wait for a few scrapes |
| cAdvisor metrics missing | Check `docker compose logs cadvisor`; continue with app metrics |
| YAML parse error | Spaces, not tabs; restore `prometheus.yml` |
| Windows file becomes `.yaml.txt` | Enable file-name extensions |

Useful logs:

```bash
docker compose logs prometheus
docker compose logs cadvisor
docker compose logs pipeline-app
docker compose logs grafana
```

---

# 23. Cleanup

Stop/remove containers:

```bash
docker compose down
```

For a completely fresh lab:

```bash
docker compose down -v
```

`-v` removes the Prometheus/Grafana stored data.

---

# 24. Final checkpoint

| Check | Completed |
|---|---|
| Docker verified | [ ] |
| Monitoring stack running | [ ] |
| Prometheus Targets checked | [ ] |
| `/metrics` inspected | [ ] |
| PromQL fundamentals tested | [ ] |
| cAdvisor metrics explored | [ ] |
| Grafana data source connected | [ ] |
| Grafana Explore tested | [ ] |
| 6 dashboard panels created | [ ] |
| Failure → DOWN demonstrated | [ ] |
| Recovery → UP demonstrated | [ ] |
| 2 challenge panels created | [ ] |
| Cleanup completed | [ ] |

---

## Instructor takeaway

The practical demonstrates the fundamentals without turning into a Prometheus/Grafana administration course:

```text
INSTRUMENT
    ↓
/metrics
    ↓
SCRAPE
    ↓
PROMETHEUS
    ↓
PromQL
    ↓
GRAFANA DATA SOURCE
    ↓
EXPLORE
    ↓
DASHBOARD
    ↓
OBSERVE → DETECT → INVESTIGATE
```
