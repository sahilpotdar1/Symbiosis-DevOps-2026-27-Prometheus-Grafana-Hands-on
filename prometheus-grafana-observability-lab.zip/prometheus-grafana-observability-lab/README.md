# Prometheus + Grafana Observability Lab

Start:
docker compose up -d --build

Open:
Prometheus  http://localhost:9090
cAdvisor    http://localhost:8080
App         http://localhost:8000
Metrics     http://localhost:8000/metrics
Grafana     http://localhost:3000

Grafana first login:
admin / admin

See OBSERVABILITY_HANDS_ON_GUIDE.md for the classroom procedure.
