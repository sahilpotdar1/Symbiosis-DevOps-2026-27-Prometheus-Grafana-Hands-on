import random
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST

# Application/service metrics
requests_total = Counter(
    "app_requests_total",
    "Total simulated application requests",
    ["endpoint", "status"],
)
request_duration = Histogram(
    "app_request_duration_seconds",
    "Simulated application request duration",
    ["endpoint"],
)
service_health = Gauge(
    "app_service_health",
    "1 when service is healthy",
)

# CI/CD pipeline metrics
pipeline_runs = Counter(
    "pipeline_runs_total",
    "Total simulated CI/CD pipeline runs",
    ["status"],
)
pipeline_duration = Histogram(
    "pipeline_duration_seconds",
    "Simulated pipeline duration",
)
pipeline_last_success = Gauge(
    "pipeline_last_run_success",
    "1 when the last pipeline run succeeded, 0 when it failed",
)
active_builds = Gauge(
    "pipeline_active_builds",
    "Number of active simulated builds",
)
deployment_status = Gauge(
    "deployment_status",
    "1 when deployment is healthy, 0 otherwise",
    ["environment"],
)

service_health.set(1)
pipeline_last_success.set(1)
deployment_status.labels("staging").set(1)
deployment_status.labels("production").set(1)
active_builds.set(0)

def record_request(endpoint="/api/orders", status="200"):
    d = random.uniform(0.03, 0.35)
    time.sleep(d)
    requests_total.labels(endpoint, status).inc()
    request_duration.labels(endpoint).observe(d)

def simulator():
    while True:
        # Simulate normal application traffic.
        for _ in range(random.randint(2, 6)):
            record_request()

        # Simulate a CI/CD pipeline run.
        active_builds.set(1)
        d = random.uniform(4, 12)
        time.sleep(d)
        success = random.random() > 0.15
        pipeline_runs.labels("success" if success else "failed").inc()
        pipeline_duration.observe(d)
        pipeline_last_success.set(1 if success else 0)
        deployment_status.labels("staging").set(1 if success else 0)
        if success:
            deployment_status.labels("production").set(1)
        active_builds.set(0)
        time.sleep(3)

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/metrics":
            data = generate_latest()
            self.send_response(200)
            self.send_header("Content-Type", CONTENT_TYPE_LATEST)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if path == "/health":
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"OK\n")
            return

        if path == "/simulate":
            for _ in range(20):
                record_request()
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Generated 20 application requests.\n")
            return

        self.send_response(200)
        self.end_headers()
        self.wfile.write(
            b"DevOps Observability Demo - /health | /metrics | /simulate\n"
        )

    def log_message(self, *_):
        return

if __name__ == "__main__":
    threading.Thread(target=simulator, daemon=True).start()
    HTTPServer(("0.0.0.0", 8000), Handler).serve_forever()
